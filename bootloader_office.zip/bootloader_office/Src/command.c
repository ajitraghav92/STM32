/**
  ******************************************************************************
  * File Name          : command.c
  * Description        : This program is the Serial flash boot loader by Xmodem data transfer
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "command.h"
#include "tim.h"
#include "serial.h"
#include "mtu2.h"
#include "flash.h"
#include "xmodem.h"
//#include "stdint.h"



/* ------- Private Variables ---------------------------------------*/

uint32_t FirstPage = 0, NbOfPages = 0;
uint32_t Address = 0, PageError = 0;

pFunction Jump_To_Application;
uint32_t JumpAddress;

static FLASH_EraseInitTypeDef EraseInitStruct = {0};



/* USER CODE BEGIN 0 */

#if ( BOOTLOADER == 1)
/*******************************************************************************************/
/*    InitCommandHandler function                                                          */
/*******************************************************************************************/
void InitCommandHandler (void)
{
	/*  Clear "software reset Flag SWRF" if it is SET */

	/* Protect register - PRCR */

	/* Module Stop */

	/* Protect register - PRCR */

	/*	UART1, UART2 initialization */
	InitSci();

	/*	Timer Initialization */
	InitMTU2_2();
}



/*******************************************************************************************/
/*    RunCommandHandler function                                                           */
/*******************************************************************************************/
void RunCommandHandler(unsigned char Mode)
{
		union union_c2s c2s;
		read_datum *p = (void*)0 ,*address = (void*)0;
		char  runcode = 0, nddd = 0;

		c2s.us = GetByte (5);          // Wait enter password for 15 sec.

		if(c2s.uc[1] == 'R')                     // Password
			{
				c2s.us = GetByte (5);
				if(c2s.uc[1] == 'X')
					{
						c2s.us = GetByte (5);
						if(c2s.uc[1] == '2')
						{
							c2s.us = GetByte (5);
						    if(c2s.uc[1] == '2')
							    {
									c2s.us = GetByte (5);
						            if(c2s.uc[1] != '0')
							        {
										c2s.uc[0] = TIMEOUT;
									}
								 }
						    else
							    {
									c2s.uc[0] = TIMEOUT;
								}
						}
					else
						{
							c2s.uc[0] = TIMEOUT;
						}
					}
				else
					{
						c2s.uc[0] = TIMEOUT;
					}
			}
		else
			{
				c2s.uc[0] = TIMEOUT;
			}


		/* Run User App on Timeout */
				if ( c2s.uc[0] == TIMEOUT )
				{
					SendLFCR();
					address = (read_datum *)(BLK_END_ADD - 7);
					nddd = *(__IO uint8_t*) address;
					if ( nddd == 2 )
					{
						p = (read_datum*)CHECK_ADD_SECOND_BLK;
					}
					else
					{
						p = (read_datum*)CHECK_ADD_FIRST_BLK;
					}

					if ( *p != 0xffffffff )
					{
						/* ReSet Process Word - Clear all Status Flags before running User Application*/
							//set_psw(0);

						SendLFCR();
						SendString((uint8_t*)"Running user program...", 23);
						SendLFCR();

						/* Call user program and never return */
						if ( nddd == 2 )
						{
							RunUserApp(SECOND_USER_FLASH_ADDR_START);
						}
						else
						{
							RunUserApp(FIRST_USER_FLASH_ADDR_START);
						}
					}
					else
					{
						/* System Reset */
						NVIC_SystemReset();
					}
				}
		else
		{
			/* Display menu on UART at which Password Bytes are received */
		//	PurgeComms( 10 );
			ShowMenu();

			#if (FLASHCODE == 1)

			while (1)
			{
				c2s.us = GetByte (10);
				if ( c2s.uc[0] == OK )
					{
						switch ( c2s.uc[1] )
							{
								case '1':
									Command_1_2(1);	              //Blank checking First Block user area
									break;

								case '2':
									Command_1_2(2);	                 //Blank checking First Block user area
									break;

								case '3':
									Command_9();	              // Update Firmware
									break;

								case '4':
									Command_5();	              // Run updated program
									break;

								default:
									ShowMenu();                   //Show Menu on Display
							}
					}
					else
					{
						  runcode++;
						  if(10 < runcode)
							{
								runcode = 0;
								/* System Reset */
								NVIC_SystemReset();
							}
					}
			}
			#endif
		}
}




/**************************************************************************************************/
/*    ShowMenu function                                                                           */
/**************************************************************************************************/
void ShowMenu (void)
{
//	union union_c2s c2s;
	SendLFCR();
	SendString( (uint8_t*)"RX220 Bootloader Main Menu ver.->3.4.02",38);
	SendLFCR();
	SendString((uint8_t*)"---------------------------------------",39);
	SendLFCR();
	SendString( (uint8_t*)"1...Blank Check User Area FIRST",31 );
	SendLFCR();
	SendString( (uint8_t*)"2...Blank Check User Area SECOND",32 );
	SendLFCR();
	SendString( (uint8_t*)"3...Firmware Updating", 21);
	SendLFCR();
	SendString( (uint8_t*)"4...RUN Updated Firmware",24 );
	SendLFCR();
	SendByte( '>' );

/* User input is taken after this func call using GetByte()*/


	   // wait for 10 seconds to receive 1 to 4
//	 c2s.us = GetByte (10);
//	if (c2s.uc[1] == '1'||c2s.uc[1] == '2'||c2s.uc[1] == '3'||c2s.uc[1] == '4')
//	{
//
//	}
//	else
//	{
////	 SYSTEM.PRCR.WORD = 0xA502;
////	 SYSTEM.SWRR = 0xA501;
//	}
}



/**************************************************************************************************/
/*    Command_9 function For Updated Firmware not Write in current running user Block - MANI      */
/**************************************************************************************************/
void Command_9 (void)
{
	SendLFCR();

	read_datum *address;
	char nddd;
	address = (read_datum *) (BLK_END_ADD - 7);

	nddd = *address;
	if ( nddd == 2 )
	{
		//Command_3();
	}

	else
	{
		Command_3();
		//Command_4 ();
	}
//	PurgeComms(2);
	ShowMenu();

}



/**************************************************************************************************/
/*    Command_3 function                                                                          */
/**************************************************************************************************/
void Command_3 (void)
{
	 uint32_t dummy = 0;
	uint32_t Onepage = 0, NOfPages = 0, in = 0;;



	// download data using xmodem and program into flash First Block
	unsigned char Status;// Shift;
//	read_datum  *address1;
//	read_datum  *address2;
	volatile unsigned long Address;// ul;
	union union_c2s c2s;
//	char RxByteBuffer[2],l_Check_First1,l_Check_First2;
//	unsigned int i;


	//+++++++++++++++++
	//  uint32_t flashdestination;// ramsource;

	  /* Initialize flashdestination variable */
	//  flashdestination = APPLICATION_ADDRESS;

	//+++++++++++++++++




	// suggest download address as the first user flash address as usually this will be the case
	SendLFCR();
	SendString( (uint8_t*)"Erase FIRST User Block",22);
	SendLFCR();

	Address = 0;
//	Shift = 28;

	SendLFCR();
	SendString((uint8_t*)FIRST_USER_FL_ADDR_TXT,12);

	SendString( (uint8_t*)"     (Y/N)?",11 );
	SendLFCR();

	/* wait for 10 seconds to receive bytes */
	c2s.us = GetByte(10);
	SendByte( c2s.uc[1] );
	SendLFCR();
	if ( c2s.uc[0] == TIMEOUT )
	{
		SendLFCR();
		SendString( (uint8_t*)"Timed out waiting for confirmation...",37 );
		SendLFCR();
		return ;
	}
	else if (  ( c2s.uc[1] == 'y' ) || ( c2s.uc[1] == 'Y' ) )
	{
		Command_6();                                     // Erase first user Block
		Address = FIRST_USER_FLASH_ADDR_START;
	}
	else
	{
	//	Command_5 ();                                     // Run updated program
	}
	SendLFCR();
	SendString( (uint8_t*)"Firmware downloading (Y/N)?",28 );
	c2s.us = GetByte( 10 );
	SendByte( c2s.uc[1] );
	if ( c2s.uc[0] == TIMEOUT )
	{
		SendLFCR();
		SendString((uint8_t*)"Timed out waiting for response!",31 );
		return ;
	}
	else if ( c2s.uc[0] == ERROR )
	{
		SendLFCR();
		SendString( (uint8_t*)"Comms Error!",12 );
		return ;
	}
	else if ( !( ( c2s.uc[1] == 'y' ) || ( c2s.uc[1] == 'Y' ) ) )
	{
		SendLFCR();
		SendString( (uint8_t*)"Firmware downloading cancelled!",31 );
		return ;
	}

		SendLFCR();

		SendString( (uint8_t*)"Start XModem download... 1",21);

		SendLFCR();




//	Flash_Unlock();
	Status = XmodemDownloadAndProgramFlash( Address );
//	Flash_Lock();
	if ( Status == XM_TIMEOUT )
	{
		SendLFCR();
		SendString( (uint8_t*)"Timeout!",9 );
		return ;
	}
	else if ( Status == XM_OK )
	{
#if (BOOTLOADER == 1)

	/* FETCH PREVIOUS FLASH DATA */
		uint64_t data = 0x0000000000000001;
		uint32_t add = BLK_UPDATE_ADD, i;
		uint32_t fetchedData[515] = {0};

		for( i = 0; add <= BLK_END_ADD ; i ++)
		{
		   fetchedData[i] = *(__IO uint32_t *)add;
		  add = add + 4;
		}


		 /****************** FLASH CODE EXAMPLE TO ERASE MEMORY *****************/
		  	  /* Unlock the Flash to enable the flash control register access *************/
	//	  		Flash_Unlock();

		  	    /* Get the 1st page to erase */
		  		Onepage = GetPage(BLK_UPDATE_ADD);

		  	    /* Get the number of pages to erase from 1st page */
		  	    NOfPages = GetPage(BLK_END_ADD) - Onepage + 1;

		  	    /* Fill EraseInit structure*/
		  	    EraseInitStruct.TypeErase   = FLASH_TYPEERASE_PAGES;
		  	    EraseInitStruct.Page        = Onepage;
		  	    EraseInitStruct.NbPages     = NOfPages;

		  	    /* Note: If an erase operation in Flash memory also concerns data in the data or instruction cache,
		  	       you have to make sure that these data are rewritten before they are accessed during code
		  	       execution. If this cannot be done safely, it is recommended to flush the caches by setting the
		  	       DCRST and ICRST bits in the FLASH_CR register. */

		  	    /* Wait for last operation to be completed */
		  	    while(READ_BIT(FLASH->SR,FLASH_SR_BSY1) == FLASH_SR_BSY1);

		  	    /*Initialization of PageError variable*/

		  	    for (in = Onepage; in < (Onepage + NOfPages); in++)
		  	    {
		  	      /* Start erase page */
		  	    	  uint32_t tmp;
		  	    	  /* Get configuration register, then clear page number */
		  	    	  tmp = (FLASH->CR & ~FLASH_CR_PNB);
		  	    	  /* Set page number, Page Erase bit & Start bit */
		  	    	  FLASH->CR = (tmp | (FLASH_CR_STRT | (in <<  FLASH_CR_PNB_Pos) | FLASH_CR_PER));


		  	      /* Wait for last operation to be completed */
		  	       while(READ_BIT(FLASH->SR,FLASH_SR_BSY1) == FLASH_SR_BSY1);
		  	    }

		  	     /* If operation is completed or interrupted, disable the Page Erase Bit */
		  	     CLEAR_BIT(FLASH->CR, FLASH_CR_PER);

		 /*****************************************************/



		 /* Update/Store Firmware Block No */
		  	   Flash_ProgramDouble_Word((BLK_END_ADD - 7),data);

		  	 Flash_Lock();

#endif








	   // l_Check_First = CHECK_ADD_FIRST_BLK;
//		address1 = (read_datum *)CHECK_ADD_FIRST_BLK11;
//		l_Check_First1 = *address1;
//		address2 = (read_datum *)CHECK_ADD_FIRST_BLK12;
//		l_Check_First2 = *address2;
	//	if (l_Check_First1==0x00 &&l_Check_First2==0xFE )
			{
			//	Command_8();
			//	RxByteBuffer[0] = 1;


				//++++++++ FLASH Write +++++++++++++++++++

				 /* Write received data in Flash */
//				  if (FLASH_Write(flashdestination, (uint32_t*) ramsource, (uint16_t) packet_length/4)  == 0)
//				  {
//
//					flashdestination += packet_length;
//
//				  }

				//+++++++++++++++++++++++++++++++++++++++++

			//	R_FlashWrite( (unsigned long)BLK_UPDATE_ADD ,(unsigned long)&RxByteBuffer[0],2 );
				SendLFCR();
				SendString( (uint8_t*)"OK - Firmware downloaded!",25 );
				SendLFCR();
				return ;
			}
//		else
//		   {
//			   SendLFCR();
//				SendString( (uint8_t*)"Firmware download FAIL!",23 );
//			//	for(i=0; i<650; i++);
//			//    SendLFCR();
//				return ;
//		   }
	}
	else if ( Status == XM_PROG_FAIL )
	{
		SendLFCR();
		SendString( (uint8_t*)"Firmware download FAIL!",23 );
		SendLFCR();
	}
	return ;
}




/**************************************/
/*    Command_6 function              */
/**************************************/
void Command_6 (void)
{
//	unsigned char uc;
//	unsigned char Status;
	union union_c2s c2s;
//	unsigned char count1;
	 uint32_t index=0;

	SendLFCR();

	SendString( (uint8_t*)"Really erase FIRST user blocks (Y/N)?",37 );
	c2s.us = GetByte( 10 );
	SendByte( c2s.uc[1] );
//	c2s.uc[1] = 'y';
//	PurgeComms( 300 );
	if ( c2s.uc[0] == TIMEOUT )
	{
		SendLFCR();
		SendString( (uint8_t*)"Timed out waiting for response",25 );
		return;
	}
	else if ( c2s.uc[0] == ERROR )
	{
		SendLFCR();
		SendString( (uint8_t*)"Comms error",11 );
		return;
	}
	else if ( !( ( c2s.uc[1] == 'y' ) || ( c2s.uc[1] == 'Y' ) ) )
	{
		SendLFCR();
		SendString( (uint8_t*)"FIRST blocks erase cancelled",28 );
		return;
	}

/****************** FLASH CODE EXAMPLE TO ERASE MEMORY *****************/
	  /* Unlock the Flash to enable the flash control register access *************/
		Flash_Unlock();

	    /* Get the 1st page to erase */
	    FirstPage = GetPage(FIRST_USER_FLASH_ADDR_START);

	    /* Get the number of pages to erase from 1st page */
	    NbOfPages = GetPage(FIRST_USER_FLASH_ADDR_END) - FirstPage + 1;

	    /* Fill EraseInit structure*/
	    EraseInitStruct.TypeErase   = FLASH_TYPEERASE_PAGES;
	    EraseInitStruct.Page        = FirstPage;
	    EraseInitStruct.NbPages     = NbOfPages;

	    /* Note: If an erase operation in Flash memory also concerns data in the data or instruction cache,
	       you have to make sure that these data are rewritten before they are accessed during code
	       execution. If this cannot be done safely, it is recommended to flush the caches by setting the
	       DCRST and ICRST bits in the FLASH_CR register. */

	    /* Wait for last operation to be completed */
	    while(READ_BIT(FLASH->SR,FLASH_SR_BSY1) == FLASH_SR_BSY1);

	    /*Initialization of PageError variable*/

	    for (index = FirstPage; index < (FirstPage + NbOfPages); index++)
	    {
	      /* Start erase page */
	    	  uint32_t tmp;
	    	  /* Get configuration register, then clear page number */
	    	  tmp = (FLASH->CR & ~FLASH_CR_PNB);
	    	  /* Set page number, Page Erase bit & Start bit */
	    	  FLASH->CR = (tmp | (FLASH_CR_STRT | (index <<  FLASH_CR_PNB_Pos) | FLASH_CR_PER));


	      /* Wait for last operation to be completed */
	       while(READ_BIT(FLASH->SR,FLASH_SR_BSY1) == FLASH_SR_BSY1);
	    }

	     /* If operation is completed or interrupted, disable the Page Erase Bit */
	     CLEAR_BIT(FLASH->CR, FLASH_CR_PER);

	    /* Lock the Flash to disable the flash control register access (recommended
	       to protect the FLASH memory against possible unwanted operation) *********/
	 //   HAL_FLASH_Lock();
	  //   Flash_Lock();


	    /*******************************************************************************/


	SendLFCR();
	SendString( (uint8_t*)"All user blocks erased", 21);
	SendLFCR();
}



/**************************************************************************************************/
/*   RunUserApp function For running user Application Block  */
/**************************************************************************************************/
void RunUserApp(uint32_t address)
{
	/* Test if user code is programmed starting from address "APPLICATION_ADDRESS" */
	if (((*(__IO uint32_t*)address) & 0x2FFE0000 ) == 0x20000000)
	{
	  /* Jump to user application */
		JumpAddress = 0;
	  JumpAddress = *(__IO uint32_t*) (address + 4);


	  Jump_To_Application = (pFunction) JumpAddress;


	  /* Initialize user application's Stack Pointer */
	  __set_MSP(*(__IO uint32_t*) address);

	  /* Jump to application */
	  Jump_To_Application();
	}
	return;
}

/**************************************************************************************************/
/*    Command_1_2 function - Check if "User Area 1" OR "User Area 2" is blank                                                                           */
/**************************************************************************************************/
void Command_1_2 (uint8_t block)
{
	read_datum *startAddress = (void*)0, *endAddress = (void*)0;
	unsigned char blank;

	SendLFCR();

	if(block == 1)
	{
		SendString((uint8_t*)"Blank checking First Block user area...",38 );
	}
	else
	{
		SendString((uint8_t*)"Blank checking Second Block user area...",40);
	}
	SendLFCR();

	if(block == 1)
	{
		startAddress = (read_datum *)FIRST_USER_FLASH_ADDR_START ;
		endAddress = (read_datum *) FIRST_USER_FLASH_ADDR_END ;
	}
	else
	{
		startAddress = (read_datum *)SECOND_USER_FLASH_ADDR_START;
		endAddress = (read_datum *)SECOND_USER_FLASH_ADDR_END;
	}


	blank = 0;
	while( startAddress < endAddress)
		{
			if ( *startAddress != BLANK_VALUE )
				{
					blank = 1; //NOT blank
					break;
				}
			startAddress++;
		}

	SendLFCR();

	if(block == 1)
	{
		SendString( (uint8_t*)"FIRST User area is",18);
	}
	else
	{
		SendString((uint8_t*) "SECOND User area is ",20 );
	}

	if ( blank == 0 )
	{
		SendString((uint8_t*)"BLANK!",6 );
		SendLFCR();
		ShowMenu();
	}
	else
	{
		SendString((uint8_t*)"NOT blank!",10);
		SendLFCR();
		ShowMenu();
	}
}


/**************************************/
/*   Command_5 : Run Program    	*/
/*************************************/

void Command_5 (void)
{
	// call the target application
	union union_c2s c2s;
	read_datum *p ,*address;
	char nddd;

	SendLFCR();                                                    // For New line
	SendString((uint8_t*)"Run user program (Y/N)?",23);
	SendLFCR();                                                    // For New line
	c2s.us = GetByte(5);
	SendByte( c2s.uc[1] );
	if ( c2s.uc[0] == TIMEOUT )
	{
		SendLFCR();
		SendString((uint8_t*)"Timed out",9);

		//PurgeComms( 300 );
		ShowMenu();
	}
	else if ( c2s.uc[0] == ERROR )
	{
		SendLFCR();
		SendString((uint8_t*)"ERROR in download",17);
		//PurgeComms( 300 );                                             //For delay
		ShowMenu();
	}
	else if ( !( ( c2s.uc[1] == 'y' ) || ( c2s.uc[1] == 'Y' ) ) )
	{
		SendLFCR();
		SendString((uint8_t*)"request cancelled",17);
		//PurgeComms( 300 );
		ShowMenu();
	}

	SendLFCR();
	address = (read_datum *)(BLK_END_ADD - 7);
	nddd = *(__IO uint8_t*) address;
	if ( nddd == 2 )
	{
		p = (read_datum*)CHECK_ADD_SECOND_BLK;
	}
	else
	{
		p = (read_datum*)CHECK_ADD_FIRST_BLK;
	}

	if ( *p != 0xffffffff )
	{
		/* ReSet Process Word - Clear all Status Flags before running User Application*/
			//set_psw(0);

		SendLFCR();
		SendString((uint8_t*)"Running user program...", 23);
		SendLFCR();

		/* Call user program and never return */
		if ( nddd == 2 )
		{
			RunUserApp(SECOND_USER_FLASH_ADDR_START);
		}
		else
		{
			RunUserApp(FIRST_USER_FLASH_ADDR_START);
		}
	}
	else
	{
		/* System Reset */
		NVIC_SystemReset();
	}
}


#endif
/* USER CODE END 0 */

/* USER CODE BEGIN 1 */



/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
