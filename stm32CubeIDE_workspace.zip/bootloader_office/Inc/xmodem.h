/**
 * @file    xmodem.h
 * @author  Ferenc Nemeth
 * @date    21 Dec 2018
 * @brief   This module is the implementation of the Xmodem protocol.
 *
 *          Copyright (c) 2018 Ferenc Nemeth - https://github.com/ferenc-nemeth
 */

#include "main.h"


#ifndef XMODEM_H_
#define XMODEM_H_

#define SOH					0x01
#define EOT					0x04
#define ACK					0x06
#define	NAK					0x15
#define CAN					0x18

#define XM_OK				0x00
#define XM_ADDRESS_ERROR	0x01
#define XM_COMMS_ERROR		0x02
#define XM_TIMEOUT			0x04
#define XM_PROG_FAIL		0x08




unsigned char XmodemDownloadAndProgramFlash (unsigned long FlashAddress);

#endif /* XMODEM_H_ */

