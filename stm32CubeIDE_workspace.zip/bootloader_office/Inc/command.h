
/**
  ******************************************************************************
  * File Name          : command.h
  * Description        : This program is the Serial flash boot loader by Xmodem data transfer
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef COMMAND_H_
#define COMMAND_H_
#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "flash.h"
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* USER CODE BEGIN Private defines */

#define FLASHCODE	1



 /*---------- Flash Addresses ----------------------*/

#define 	FIRST_USER_FLASH_ADDR_START					(FLASH_BASE + (10 * FLASH_PAGE_SIZE))   /* Start @ of user Flash area */
#define 	FIRST_USER_FLASH_ADDR_END					(FLASH_BASE + (30 * FLASH_PAGE_SIZE))   /* Start @ of user Flash area */

 //#define 	FIRST_USER_FLASH_ADDR_START					(FLASH_BASE + (3 * FLASH_PAGE_SIZE))   /* Start @ of user Flash area */
//#define 	FIRST_USER_FLASH_ADDR_END					(FLASH_BASE + (30 * FLASH_PAGE_SIZE))   /* Start @ of user Flash area */
#define 	CHECK_ADD_FIRST_BLK				            (FLASH_BASE + (30 * FLASH_PAGE_SIZE) - 0x00000004UL)
#define 	CHECK_ADD_FIRST_BLK11				        (FLASH_BASE + (30 * FLASH_PAGE_SIZE) - 0x00000002UL)
#define 	CHECK_ADD_FIRST_BLK12				        (FLASH_BASE + (30 * FLASH_PAGE_SIZE) - 0x00000001UL)
#define 	SECOND_USER_FLASH_ADDR_START				(FLASH_BASE + (31 * FLASH_PAGE_SIZE))
#define 	SECOND_USER_FLASH_ADDR_END					(FLASH_BASE + (63 * FLASH_PAGE_SIZE))
#define 	CHECK_ADD_SECOND_BLK				        (FLASH_BASE + (63 * FLASH_PAGE_SIZE) - 3)
#define 	CHECK_ADD_SECOND_BLK21				        (FLASH_BASE + (63 * FLASH_PAGE_SIZE) - 2)
#define 	CHECK_ADD_SECOND_BLK22				        (FLASH_BASE + (63 * FLASH_PAGE_SIZE) - 1)
#define     BLK_UPDATE_ADD                              FLASH_BASE
#define 	FLASH_LINE_SIZE        						128

#define FLASH_USER_START_ADDR   (FLASH_BASE + (3 * FLASH_PAGE_SIZE))   /* Start @ of user Flash area */
#define FLASH_USER_END_ADDR     (FLASH_BASE + FLASH_SIZE - 1)   /* End @ of user Flash area */


#define FIRST_USER_FL_ADDR_TXT		"0x8005000"  // 10th page address
#define SECOND_USER_FL_ADDR_TXT		"FFFED800"



typedef unsigned long read_datum;

/* USER CODE END Private defines */

/* USER CODE BEGIN Prototypes */
#if ( BOOTLOADER == 1)
 void InitCommandHandler (void);
 void RunCommandHandler (unsigned char Mode);
 void ShowMenu (void);

 void Command_9 (void);
 void Command_3 (void);
 void Command_6 (void);

 typedef  void (*pFunction)(void);


#endif
/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif
#endif /*__ COMMAND_H_ */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
