/*
 * flash.c
 *
 *  Created on: Jun 11, 2019
 *
 */
#include "flash.h"
#include "command.h"

void Flash_Init(void)
{
	/* Configure Flash prefetch, Instruction cache             */
	/* Default configuration at reset is:                      */
	/* - Prefetch disabled                                     */
	/* - Instruction cache enabled                             */

	#if (INSTRUCTION_CACHE_ENABLE == 0U)
	__FLASH_INSTRUCTION_CACHE_DISABLE();
	#endif /* INSTRUCTION_CACHE_ENABLE */

#if (PREFETCH_ENABLE != 0U)
	__FLASH_PREFETCH_BUFFER_ENABLE();
#endif /* PREFETCH_ENABLE */


}


uint8_t Flash_Unlock(void)
{
	  if (READ_BIT(FLASH->CR, FLASH_CR_LOCK) != 0x00U)
	  {
	    /* Authorize the FLASH Registers access */
	    WRITE_REG(FLASH->KEYR, FLASH_KEY1);
	    WRITE_REG(FLASH->KEYR, FLASH_KEY2);

	    /* Clear all FLASH flags */
	    FLASH->SR = FLASH_SR_EOP|FLASH_SR_WRPERR | FLASH_SR_PGAERR | FLASH_SR_BSY1;

	    /* verify Flash is unlock */
	    if (READ_BIT(FLASH->CR, FLASH_CR_LOCK) != 0x00U)
	    {
	    	/* Error */
	      return 0;
	    }
	  }
	  return 1;
}



/**
  * @brief  Gets the page of a given address
  * @param  Addr: Address of the FLASH Memory
  * @retval The page of a given address
  */
uint32_t GetPage(uint32_t Addr)
{
  return (Addr - FLASH_BASE) / FLASH_PAGE_SIZE;;
}



/**
  * @brief  This function writes a data buffer in flash (data are 32-bit aligned).
  * @note   After writing data buffer, the flash content is checked.
  * @param  destination: start address for writing data buffer
  * @param  p_source: pointer on data buffer
  * @param  length: length of data buffer (unit is 32-bit word)
  * @retval 0: Data successfully written to Flash memory
  *         1: Error occurred while writing data in Flash memory
  *         2: Written Data in flash memory is different from expected one
  */
uint32_t FLASH_Write(uint32_t destination, uint32_t *p_source, uint32_t length)
{
  uint32_t i = 0;

  /* DataLength must be a multiple of 64 bit */
  for (i = 0; (i < length/2) && (destination <= (FIRST_USER_FLASH_ADDR_START-8)); i++)
  {
    /* Device voltage range supposed to be [2.7V to 3.6V], the operation will
       be done by word */
    if (Flash_ProgramDouble_Word(destination,*((uint64_t *)(p_source+2*i))) == 0)
    {
      /* Check the written value */
      if (*(uint64_t*)destination != *(uint64_t *)(p_source+2*i))
      {
        /* Flash content doesn't match SRAM content */
         return 2;
      }

      /* Increment FLASH destination address */
      destination += 8;
    }
    else
    {
      /* Error occurred while writing data in Flash memory */
      return -1;
    }
  }

  return 0;
}



uint32_t Flash_ProgramDouble_Word(uint32_t Address, uint64_t Data)
{


  while(READ_BIT(FLASH->SR,FLASH_SR_BSY1) == FLASH_SR_BSY1);
  /* Set PG bit */
  SET_BIT(FLASH->CR, FLASH_CR_PG);

  /* Program first word */
  //*(uint32_t *)Address = (uint32_t)temp2;
   *(uint32_t *)Address = (uint32_t)Data;

  /* Barrier to ensure programming is performed in 2 steps, in right order
  (independently of compiler optimization behavior) */
  __ISB();


  /* Program second word */
 *(uint32_t *)(Address + 4U) = (uint32_t)(Data >> 32U);
 //*(uint32_t *)(Address + 4U)=temp2;

  /* Wait for last operation to be completed */
  while(READ_BIT(FLASH->SR,FLASH_SR_BSY1) == FLASH_SR_BSY1);

  /* If the program operation is completed, disable the PG or FSTPG Bit */
  CLEAR_BIT(FLASH->CR, FLASH_CR_PG);
  return 0;

}


uint8_t Flash_Lock(void)
{
	uint8_t status = 1;
	/* Set the LOCK Bit to lock the FLASH Registers access */
	SET_BIT(FLASH->CR, FLASH_CR_LOCK);

	/* verify Flash is locked */
	if (READ_BIT(FLASH->CR, FLASH_CR_LOCK) != 0x00u)
	{
		status = 0;
	}

	return status;
}
