/**
  ******************************************************************************
  * File Name          : mtu2.c
  * Description        : Code to initialize the Timer
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "mtu2.h"
#include "tim.h"

/* USER CODE BEGIN 0 */
#if ( BOOTLOADER == 1)
/*******************************************************************************
* Function Name : InitMTU2_2
* Description	: Initialize Timer 6
* Parameters	: none
* Return value  : none
*******************************************************************************/
void InitMTU2_2(void)
{
	/*	Initialize Basic Timer with 1 second clock */
	MX_TIM6_Init();
}


/*******************************************************************************
* Function Name : StartMTU2_2
* Description	: Start MTU2 Channel 2
* Parameters	: none
* Return value  : none
*******************************************************************************/
void StartMTU2_2(void)
{
//	MTU2.TCNT = 0;
//	MTU.TSTR.BIT.CST2 = 1;			/* Start MTU2_2 */

	LL_TIM_ClearFlag_UPDATE(TIM6);

	/* Enable the update interrupt */
	LL_TIM_EnableIT_UPDATE(TIM6);

	/* Enable counter */
	LL_TIM_EnableCounter(TIM6);
}

/*******************************************************************************
* Function Name : StopMTU2_2
* Description	: Stop MTU2 Channel 2
* Parameters	: none
* Return value  : none
*******************************************************************************/
void StopMTU2_2(void)
{
	//MTU.TSTR.BIT.CST2 = 0;			/* Stop MTU2_2 */
	LL_TIM_ClearFlag_UPDATE(TIM6);
		TIM6->CR1 = 0;
		TIM6->DIER = 0;
}


#endif
/* USER CODE END 0 */

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
