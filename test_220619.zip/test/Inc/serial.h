
/**
  ******************************************************************************
  * File Name          : command.h
  * Description        : This program is the Serial flash boot loader by Xmodem data transfer
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef SERIAL_H_
#define SERIAL_H_
#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* USER CODE BEGIN Private defines */
#if ( BOOTLOADER == 1)






#define MS_PER_TIMER_COMPARE_MATCH				1
#define LINEFEED								10
#define CARRIAGE_RETURN							13
#define ESCAPE									27
#define BACKSPACE								8

// status info
#define OK										0
#define ERROR									1
#define TIMEOUT									2

#define TX_IN_PROGRESS							1
#define TX_NOT_IN_PROGRESS						0



#define TOCHANGE	1


#endif
/* USER CODE END Private defines */

/* USER CODE BEGIN Prototypes */
#if ( BOOTLOADER == 1)
 void InitSci ( void );
 void SendLFCR( void );
 void SendByte ( unsigned char b );
 void PurgeComms ( unsigned long timeout );
 unsigned short GetByte ( unsigned long timeout );
 unsigned char RxByteWaiting ( void );
 unsigned char CheckIRFlag(void);
 //void SendString ( char *str );
 void SendString(uint8_t * ptr, uint16_t len);
#endif

/* USER CODE END Prototypes */


 /* Private typedef -----------------------------------------------------------*/
 /* USER CODE BEGIN PTD */

 union union_c2s {
  	unsigned char uc[2]; /* uc[0] -> lsb (b7--b0); uc[1] -> msb (b15--b8) */
  	unsigned short us;
  };


 /* USER CODE END PTD */



#ifdef __cplusplus
}
#endif
#endif /*__ SERIAL_H_ */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
