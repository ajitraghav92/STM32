/*
 * flash.h
 *
 *
 */

#ifndef FLASH_H_
#define FLASH_H_


#include "main.h"

/*------------------- Private Macros ---------------------------*/

/** FLASH Keys
  *
  */
#define FLASH_KEY1                      0x45670123U   /*!< Flash key1 */
#define FLASH_KEY2                      0xCDEF89ABU   /*!< Flash key2: used with FLASH_KEY1 */


#define FLASH_TYPEERASE_PAGES           FLASH_CR_PER    /*!< Pages erase only */

#define FLASH_SIZE_DATA_REGISTER        FLASHSIZE_BASE

#define FLASH_SIZE                      (((*((uint32_t *)FLASH_SIZE_DATA_REGISTER)) & (0x00FFU)) << 10U)

#define FLASH_PAGE_SIZE                 0x00000800U    /*!< FLASH Page Size, 2 KBytes */

#ifndef INSTRUCTION_CACHE_ENABLE
#define  INSTRUCTION_CACHE_ENABLE     1U
#endif

#ifndef PREFETCH_ENABLE
#define  PREFETCH_ENABLE              1U
#endif


/* define the address from where user application will be loaded,
   the application address should be a start sector address */
#define APPLICATION_ADDRESS     (uint32_t)0x08005000

//
//#define SET_BIT(REG, BIT)     ((REG) |= (BIT))
//
//#define CLEAR_BIT(REG, BIT)   ((REG) &= ~(BIT))
//

/**
  * @brief  Enable the FLASH instruction cache.
  * @retval none
  */
#define __FLASH_INSTRUCTION_CACHE_ENABLE()  SET_BIT(FLASH->ACR, FLASH_ACR_ICEN)

/**
  * @brief  Disable the FLASH instruction cache.
  * @retval none
  */
#define __FLASH_INSTRUCTION_CACHE_DISABLE() CLEAR_BIT(FLASH->ACR, FLASH_ACR_ICEN)


#define __FLASH_PREFETCH_BUFFER_ENABLE()    SET_BIT(FLASH->ACR, FLASH_ACR_PRFTEN)




/*--------------- Private typedef --------------------------------*/

/**
  * @brief  FLASH Erase structure definition
  */
typedef struct
{
  uint32_t TypeErase;   /*!< Mass erase or page erase.
                             This parameter can be a value of @ref FLASH_Type_Erase */
  uint32_t Page;        /*!< Initial Flash page to erase when page erase is enabled
                             This parameter must be a value between 0 and (FLASH_PAGE_NB - 1) */
  uint32_t NbPages;     /*!< Number of pages to be erased.
                             This parameter must be a value between 1 and (FLASH_PAGE_NB - value of initial page)*/
} FLASH_EraseInitTypeDef;



/*---------------- Private Prototypes --------------------------------*/

void Flash_Init(void);
uint8_t Flash_Unlock(void);
uint32_t GetPage(uint32_t Addr);
uint32_t Flash_ProgramDouble_Word(uint32_t Address, uint64_t Data);
uint8_t Flash_Lock(void);
uint32_t FLASH_Write(uint32_t destination, uint32_t *p_source, uint32_t length);

#endif /* FLASH_H_ */
