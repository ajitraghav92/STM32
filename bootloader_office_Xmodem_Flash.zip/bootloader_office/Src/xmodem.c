/**
 *           Copyright (c) HPL
 */

#include "command.h"
#include "xmodem.h"
#include "serial.h"
#include <string.h>

/* Global variables. */

#define 	PROG_PASS 	1
#define 	PROG_FAIL	0
#define		XMODEM_BUFFER_SIZE			128 + 4 + 1



unsigned char Received=0;

/* Local functions. */

unsigned char XmodemDownloadAndProgramFlash (unsigned long FlashAddress)
{
	unsigned char ExpectedBlkNum;
	unsigned char RetryCounter;
	unsigned long RxByteCount;
	unsigned char RxByteBufferIndex;

	unsigned char Status;
	unsigned char checksum;
	unsigned char StartCondition;
	unsigned long Address;
	union union_c2s c2s;

	volatile union {
		unsigned char uc[ XMODEM_BUFFER_SIZE ];
		read_datum ur[ (XMODEM_BUFFER_SIZE) / sizeof (read_datum) ];
	} RxByteBuffer;


//	volatile union {
//		unsigned char uc[ FLASH_LINE_SIZE ];
//		read_datum ur[ FLASH_LINE_SIZE / sizeof (read_datum) ];
//	} ProgData;



	// To ensure that data is stored starting on the right size boundary for the Flash
	// an extra byte is needed as this buffer must store the xmodem protocol bytes
	// and the data bytes.  This means that a padding byte is added
	// at the beginning of the buffer.

	// first xmodem block number is 1
	ExpectedBlkNum = 1;

	StartCondition = 0;

	Address = FlashAddress;
	//PurgeComms( 1000 );

	// clear any garbage , if any
	//memset(RxByteBuffer.uc,'\0',135);

	while(1)
		{
			//	{1}
			//	initialise Rx attempts
			RetryCounter = 10;
			//	decrement Rx attempts counter & get Rx byte with a 10 sec timeout repeat until Rx attempts is 0
			c2s.uc[0] = TIMEOUT;
			while ( (RetryCounter > 0) && (c2s.uc[0] == TIMEOUT) )
			{
				if (StartCondition == 0)
				{
					//	if this is the start of the xmodem frame
					//	send a NAK to the transmitter
					SendByte( NAK );
					c2s.us = GetByte( 5 );
					//		nop();
				}
				else
				{
					c2s.us = GetByte( 5 );
					//	nop();
				}
				RetryCounter--;
				//	WatchDog();
			}

				StartCondition = 1;

			//	if timed out after 10 attempts or comms error
			//	return relevant error state to caller
			if ( c2s.uc[0] == TIMEOUT )
				{
					return ( XM_TIMEOUT );
				}
			else if ( c2s.uc[0] == ERROR )
				{
					// loop back to (1)
					// do nothing
					return ( XM_COMMS_ERROR );
				}
			else
				{
					// if first received byte is 'end of frame'
					// return ACK to sender and exit
					if ( c2s.uc[1] == EOT )
						{

							SendByte( ACK );
							return( XM_OK );
						}
					else
						{
							//	initialise counter for incoming Rx bytes
							// start of header + block num + (255 - block num) + 128 data bytes + checksum
							RxByteCount = 128 + 4;
							// RxByteBufferIndex is initiales to 1 to ensure correct boundary for the data
							RxByteBufferIndex = 1;

							Status = XM_OK;

							// store the byte we have just received
							RxByteBuffer.uc[ RxByteBufferIndex++ ] = c2s.uc[1];
							RxByteCount--;

							while( RxByteCount > 0 )
							{
								//	get Rx byte with 1 second timeout
								c2s.us = GetByte( 30 );

								//	if timed out or comms error
								if ( (c2s.uc[0] == TIMEOUT) || (c2s.uc[0] == ERROR) )
								{
									Status = XM_TIMEOUT;
									//	timed out so purge incoming data
									//PurgeComms( 1000 );
									// send NAK and return loop back start of while loop
									SendByte( NAK );
									RxByteCount = 0;
								}
								else
								{
									// no timeout or comms error
									// store Rx byte
									RxByteBuffer.uc[ RxByteBufferIndex++ ] = c2s.uc[1];
									RxByteCount--;
								}
							}
							if (Status == XM_TIMEOUT)
							{
								// loop back to (1)
								// do nothing
							}
							else
								{
									// data Rx ok
									// calculate the checksum of the data bytes only
									checksum = 0;
									for (RxByteBufferIndex=0; RxByteBufferIndex<128; RxByteBufferIndex++)
									{
										checksum += RxByteBuffer.uc[ RxByteBufferIndex + 3 + 1 ];
									}
									//	if SOH, BLK#, 255-BLK# or checksum not valid
									//	(BLK# is valid if the same as expected blk counter or is 1 less
									if ( !( (RxByteBuffer.uc[0 + 1] == SOH) && ((RxByteBuffer.uc[1 + 1] == ExpectedBlkNum) || (RxByteBuffer.uc[1 + 1] == ExpectedBlkNum - 1) ) && (RxByteBuffer.uc[2 + 1] + RxByteBuffer.uc[1 + 1] == 255 ) && (RxByteBuffer.uc[131 + 1] == checksum) ) )
										{
											//	send NAK and loop back to (1)
											SendByte( NAK );
										//	SendByte( NAK );    //Mani 15/09/2016
										}
									else
										{
											//	if blk# is expected blk num
											if ( RxByteBuffer.uc[1 + 1] == ExpectedBlkNum )
											   {
												//	nop();
												//	Status = R_FlashWrite( 	(unsigned long)Address,(unsigned long)&RxByteBuffer.uc[3+1],128	);

												Status = FLASH_Write((unsigned long)Address,(uint32_t*)&RxByteBuffer.uc[3+1],128/4);

												//	Status = 0;
													if(Status == 0)
														Status = PROG_PASS;
													else
														Status = PROG_FAIL;

													if( Status == PROG_PASS )
														{
															//	if prog routine passed ok increment flash address
															Address += 128;
															ExpectedBlkNum++;
															SendByte( ACK );
														}
													else
														{
															// prog fail
															SendByte( NAK );
														//	nop();
															// cancel xmodem download
															SendByte( CAN );
															return( XM_PROG_FAIL );
														}
												}
											else
												{
													// 	block number is valid but this data block has already been received
													//	send ACK and loop to (1)
													SendByte( ACK );
												}
										}
								}
						  }
					}
			}
}




