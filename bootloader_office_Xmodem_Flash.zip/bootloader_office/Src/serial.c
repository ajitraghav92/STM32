/**
  ******************************************************************************
  * File Name          : serial.c
  * Description        : This file provides code for serial communication
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "serial.h"
#include "usart.h"
#include "gpio.h"
#include "stm32g0xx.h"
#include "mtu2.h"

/* Private variables ---------------------------------------------------------*/
extern uint8_t msTick;
unsigned char tmpt,tmpr,uart_sel_flag=0;

/* Private function prototypes -----------------------------------------------*/
#if (BOOTLOADER == 0)
 static unsigned char TxByteEmpty ( void );
 static void TxByteLoad( unsigned char b );
#endif

/* USER CODE BEGIN 0 */
#if ( BOOTLOADER == 1)

/****************************************/
/*    InitSci function                  */
/****************************************/
void InitSci ( void )
{
	  MX_GPIO_Init();
	  MX_USART1_UART_Init();
	  MX_USART2_UART_Init();
}

/****************************************/
/*    SendLFCR function          		*/
/****************************************/
void SendLFCR( void )
{
//	SendString((uint8_t*)"\n\r", 2);
	SendByte( LINEFEED );
	SendByte( CARRIAGE_RETURN );
}

/****************************************/
/*    SendByte function	    			*/
/****************************************/
void SendByte ( unsigned char b )
{
	uint8_t byte[2] = {0};
	byte[0] = (uint8_t)b;
	SendString(byte, 1);
//    unsigned char i;
//
//    /* Check Tx Empty flag */
//	while( TxByteEmpty() == 0 );
//
//	/* Load value in TDR register */
//	TxByteLoad( b );
//
//	if(uart_sel_flag==5)
//	{
//		/* Clear TDR flag */
//		//CLEAR_BIT(USART2->ISR, USART_ISR_TXE_TXFNF);
//
//		/* snippet to clear TC flag */
//		LL_USART_ClearFlag_TC(USART2);
//
//		while (!LL_USART_IsActiveFlag_TC(USART2))
//		{
//			/* Wait for TC flag to be raised for last char */
//		}
//	}
//	else if(uart_sel_flag==6)
//	{
//		/* Clear TDR flag */
//		//CLEAR_BIT(USART1->ISR, USART_ISR_TXE_TXFNF);
//
//		/* snippet to clear TC flag */
//		LL_USART_ClearFlag_TC(USART1);
//
//		while (!LL_USART_IsActiveFlag_TC(USART1))
//		{
//			/* Wait for TC flag to be raised for last char */
//		}
//	}
//	else
//	{
//		/* Clear TDR flag */
//	//	CLEAR_BIT(USART2->ISR, USART_ISR_TXE_TXFNF);
//
//		/* snippet to clear TC flag */
//		//LL_USART_ClearFlag_TC(USART2);
//
////		while (!LL_USART_IsActiveFlag_TC(USART2))
////		{
////			/* Wait for TC flag to be raised for last char */
////		}
//		for (i=0; i<65; i++);
//
//		/* Clear TDR flag */
////		CLEAR_BIT(USART1->ISR, USART_ISR_TXE_TXFNF);
//
//
//		/* snippet to clear TC flag */
////		LL_USART_ClearFlag_TC(USART1);
////
////		while (!LL_USART_IsActiveFlag_TC(USART1))
////		{
////			/* Wait for TC flag to be raised for last char */
////		}
//	}
}

/****************************************/
/*    PurgeComms function       		*/
/****************************************/
void PurgeComms ( unsigned long timeout )
{
	union union_c2s c2s;
	do {
		c2s.us = GetByte( timeout );
	} while( (c2s.uc[0] != TIMEOUT) && (c2s.uc[0] != ERROR) );

	  /* Reset UART flag on which garbage was received */
	  uart_sel_flag = 0;
}


/****************************************/
/*    GetByte function       			*/
/****************************************/
unsigned short GetByte ( unsigned long timeout )
{
	//	timeout = time in ms for which to timeout the data reception
	//
	//	returns a 16-bit value
	//	upper (msb) byte contains status info
	//	lower (lsb) byte contains the data received from the SCI channel
	//
	//	status:
	//	OK
	//	ERROR
	//	TIMEOUT
	//

	union union_c2s c2s;
	unsigned long tick_count;

	tick_count = timeout / MS_PER_TIMER_COMPARE_MATCH;

	/* Timer Start */
	StartMTU2_2();

	// wait for a byte to arrive
	while ( ( RxByteWaiting() == 0 ) && (tick_count) )
	{
		/* Check Timeout Flag */
		if ( CheckIRFlag() )
		{
			//StopMTU2_2();
			if ( --tick_count )
			{
			//	StartMTU2_2();
//					WatchDog();
			}
		}
	}
	/* Stop Timer */
	StopMTU2_2();

	if ( tmpr )
	{

	// read error flags and data

		if(uart_sel_flag==5)
		{
			c2s.us = LL_USART_ReceiveData8(USART2);
		}
		else if(uart_sel_flag==6)
		{
			c2s.us = LL_USART_ReceiveData8(USART1);
		}
		else
		{
			c2s.us = LL_USART_ReceiveData8(USART2);
			c2s.us = LL_USART_ReceiveData8(USART1);
         }

/* Error Callback at time of Receiving byte from IRQ handler*/
		// check for errors
/*
		if(( c2s.uc[1] & 0x80 )||(SCI9.SSR.BIT.PER == 1)||(SCI9.SSR.BIT.FER == 1)||(SCI9.SSR.BIT.ORER == 1)\
		||(SCI6.SSR.BIT.PER == 1)||(SCI6.SSR.BIT.FER == 1)||(SCI6.SSR.BIT.ORER == 1))
		{
			// Rx error
			//
			// check for parity error
			if( c2s.uc[1] & 0x40 )
			{
				// parity error
			}
			// check for framing error
			if( c2s.uc[1] & 0x20 )
			{
				// framing error
			}
			// check for overrun error
			if( c2s.uc[1] & 0x10 )
			{
				// overrun error
				// clearing the overrun error flag is a special case
				//
				// clear Tx enable

			//	SCI9.SCR.BIT.RE = 0;
			//	SCI9.SCR.BIT.TE = 0;
				// set Tx enable

			//	SCI9.SCR.BYTE = 0x30;
			}

			c2s.uc[ 0 ] = ERROR;
			SCI9.SSR.BIT.PER = 0;
			SCI9.SSR.BIT.FER = 0;
			SCI9.SSR.BIT.ORER = 0;
			SCI6.SSR.BIT.PER = 0;
			SCI6.SSR.BIT.FER = 0;
			SCI6.SSR.BIT.ORER = 0;
		}
		else
		{
			// no Rx error
			c2s.uc[ 1 ] = c2s.uc[ 0 ];
			c2s.uc[ 0 ] = OK;
		}
*/


#if (TOCHANGE == 1)

	//	else
	//			{
					// no Rx error
					c2s.uc[ 1 ] = c2s.uc[ 0 ];
					c2s.uc[ 0 ] = OK;
	//			}
#endif


	}
	else
	{
		c2s.uc[0] = TIMEOUT;
/*

		//if( c2s.uc[1] & 0x80 )
		//{
		//	c2s.uc[ 0 ] = ERROR;
			SCI9.SSR.BIT.PER = 0;
			SCI9.SSR.BIT.FER = 0;
			SCI9.SSR.BIT.ORER = 0;
			SCI6.SSR.BIT.PER = 0;
			SCI6.SSR.BIT.FER = 0;
			SCI6.SSR.BIT.ORER = 0;

		//}
*/

	}

	return (c2s.us);
}



/****************************************/
/*    RxByteWaiting function			*/
/****************************************/
unsigned char RxByteWaiting ( void )
{
	if(uart_sel_flag==0)
	{
	   if(LL_USART_IsActiveFlag_RXNE(USART2))
		{
			uart_sel_flag =5;
			tmpr = 1;
		}
		else if(LL_USART_IsActiveFlag_RXNE(USART1))
		{
			uart_sel_flag = 6;
			tmpr = 1;
		}
		else
		{
			tmpr = 0;
		}
	}
	else if(uart_sel_flag==5)
	{
		if(!LL_USART_IsActiveFlag_RXNE(USART2))
		{
			tmpr = 0;
		}
		else
		{
			tmpr = 1;
		}
	}
	else
	{
		if(!LL_USART_IsActiveFlag_RXNE(USART1))
		{
			tmpr = 0;
		}
		else
		{
			tmpr = 1;
		}
	}
	return tmpr;
}


/*******************************************************************************
* Function Name : CheckIRFlag
* Description	: Check the state of the IR bit
* Parameters	: none
* Return value  : Value of the IR bit
*******************************************************************************/
unsigned char CheckIRFlag(void)
{
	/* Check Timeout Flag */
// 	if(ICU.IR[126].BIT.IR == 1)
	if(msTick)
	{
//		ICU.IR[126].BIT.IR = 0;
		msTick = 0;
		return 1;
	}
	else
	{
		return 0;
	}

}



/****************************************/
/*    SendString function   			*/
/****************************************/
//void SendString ( char far *str )
//void SendString ( char *str )
//{
//	// sends string until NUL terminator is reached
//	unsigned short us;
//	us = 0;
//	while ( str[us] != 0 )
//	{
//		SendByte ( (unsigned char) str[us] );
//		us++;
//	}
//}





///**
//  * @brief  Function called for achieving TX buffer sending
//  * @param  None
//  * @retval None
//  */
void SendString(uint8_t * ptr, uint16_t len)
{
	uint16_t ubSend = 0;
	if(uart_sel_flag==5)
	{
	  /* Send characters one by one, until last char to be sent */
	  while (ubSend <= len)
	  {
		/* Wait for TXE flag to be raised */
		while (!LL_USART_IsActiveFlag_TXE(USART2))
		{
		}
		/* If last char to be sent, clear TC flag */
		if (ubSend == len)
		{
		  LL_USART_ClearFlag_TC(USART2);
		  break;
		}
		else
		{
			/* Write character in Transmit Data register.
			   TXE flag is cleared by writing data in TDR register */
			LL_USART_TransmitData8(USART2, *(ptr+ubSend));
			ubSend++;
		}
	  }

	  while (!LL_USART_IsActiveFlag_TC(USART2))
	  {
		  /* Wait for TC flag to be raised for last char */
	  }
	}
	else if(uart_sel_flag==6)
	{
	/* Send characters one by one, until last char to be sent */
	  while (ubSend <= len)
	  {
		/* Wait for TXE flag to be raised */
		while (!LL_USART_IsActiveFlag_TXE(USART1))
		{
		}
		/* If last char to be sent, clear TC flag */
		if (ubSend == len)
		{
		  LL_USART_ClearFlag_TC(USART1);
		  break;
		}
		else
		{
			/* Write character in Transmit Data register.
			   TXE flag is cleared by writing data in TDR register */
			LL_USART_TransmitData8(USART1, *(ptr+ubSend));
			ubSend++;
		}
	  }

	  while (!LL_USART_IsActiveFlag_TC(USART1))
	  {
		  /* Wait for TC flag to be raised for last char */
	  }
	}
	else
	{
		  /* Send characters one by one, until last char to be sent */
				  while (ubSend <= len)
				  {
				    /* Wait for TXE flag to be raised */
				    while (!LL_USART_IsActiveFlag_TXE(USART2))
				    {
				    }
				    /* If last char to be sent, clear TC flag */
				    if (ubSend == len)
				    {
				      LL_USART_ClearFlag_TC(USART2);
				      break;
				    }
				    else
				    {
						/* Write character in Transmit Data register.
						   TXE flag is cleared by writing data in TDR register */
						LL_USART_TransmitData8(USART2, *(ptr+ubSend));
						ubSend++;
				    }
				  }

				  while (!LL_USART_IsActiveFlag_TC(USART2))
				  {
					  /* Wait for TC flag to be raised for last char */
				  }



				  ubSend = 0;



				  /* Send characters one by one, until last char to be sent */
				  	  while (ubSend <= len)
				  	  {
				  		/* Wait for TXE flag to be raised */
				  		while (!LL_USART_IsActiveFlag_TXE(USART1))
				  		{
				  		}
				  		/* If last char to be sent, clear TC flag */
				  		if (ubSend == len)
				  		{
				  		  LL_USART_ClearFlag_TC(USART1);
				  		  break;
				  		}
				  		else
				  		{
							/* Write character in Transmit Data register.
							   TXE flag is cleared by writing data in TDR register */
							LL_USART_TransmitData8(USART1, *(ptr+ubSend));
							ubSend++;
				  		}
				  	  }

				  	  while (!LL_USART_IsActiveFlag_TC(USART1))
				  	  {
				  		  /* Wait for TC flag to be raised for last char */
				  	  }
	}
}



#endif
/* USER CODE END 0 */


/* USER CODE BEGIN 1 */

#if (BOOTLOADER == 0)
/****************************************/
/*    TxByteEmpty function				*/
/****************************************/
static unsigned char TxByteEmpty ( void )
{
	// returns 1 - if the UART transmit register is empty
	// returns 0 - if the UART transmit register is not empty
	if(uart_sel_flag==0)
	{
		if(LL_USART_IsActiveFlag_TXE(USART1))
		{
			tmpt = 1;
		}
		else if(LL_USART_IsActiveFlag_TXE(USART2))
		{
			tmpt = 1;
		}
		else
		{
			tmpt = 0;
		}
	}
	else if(uart_sel_flag == 6)
	{
		if(!LL_USART_IsActiveFlag_TXE(USART1))
		{
			tmpt = 0;
		}
		else
		{
			tmpt = 1;
		}
	}
	else
	{
		if(!LL_USART_IsActiveFlag_TXE(USART2))
		{
			tmpt = 0;
		}
		else
		{
			tmpt = 1;
		}
	}
	return tmpt;
}



/****************************************/
/*    TxByteLoad function				*/
/****************************************/
static void TxByteLoad( unsigned char b )
{
	unsigned char i;
	if(uart_sel_flag==5)
	{
		LL_USART_TransmitData8(USART2,b);
		//USART2->TDR = b;
	}
	else if(uart_sel_flag==6)
	{
		LL_USART_TransmitData8(USART1,b);
		//USART1->TDR = b;
	}
	else
	{
		LL_USART_TransmitData8(USART2,b);
		//USART2->TDR = b;
		for (i=0; i<65; i++);
		LL_USART_TransmitData8(USART1,b);
		//USART1->TDR = b;
	}
}


#endif
/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
