/**
  ******************************************************************************
  * File Name          : command.c
  * Description        : This program is the Serial flash boot loader by Xmodem data transfer
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "command.h"
#include "tim.h"
#include "serial.h"
#include "mtu2.h"
#include "flash.h"
#include "xmodem.h"
//#include "stdint.h"

/* ------- Private Variables ---------------------------------------*/

uint32_t FirstPage = 0, NbOfPages = 0;
uint32_t Address = 0, PageError = 0, EndAddress = 0;
 FLASH_EraseInitTypeDef EraseInitStruct = {0};

/* USER CODE BEGIN 0 */

#if ( BOOTLOADER == 1)
/*******************************************************************************************/
/*    InitCommandHandler function                                                          */
/*******************************************************************************************/
void InitCommandHandler (void)
{
	/*  Clear "software reset Flag SWRF" if it is SET */

	/* Protect register - PRCR */

	/* Module Stop */

	/* Protect register - PRCR */

	/*	UART1, UART2 initialization */
	InitSci();

	/*	Timer Initialization */
	InitMTU2_2();
}



/*******************************************************************************************/
/*    RunCommandHandler function                                                           */
/*******************************************************************************************/
void RunCommandHandler(unsigned char Mode)
{
		union union_c2s c2s;
		read_datum *p ,*address;
		char  runcode, nddd;

		/* Start Entering Password before 10 seconds Timeout*/
		c2s.us = GetByte (5);

		if(c2s.uc[1] == 'R')
		{
			c2s.us = GetByte (3);
			if(c2s.uc[1] == 'X')
			{
				c2s.us = GetByte (3);
				if(c2s.uc[1] == '2')
				{
					c2s.us = GetByte (3);
					if(c2s.uc[1] == '2')
					{
						c2s.us = GetByte (3);
						if(c2s.uc[1] != '0')
						{
							c2s.uc[0] = TIMEOUT;
						}
					}
					else
					{
						c2s.uc[0] = TIMEOUT;
					}
				}
				else
				{
					c2s.uc[0] = TIMEOUT;
				}
			}
			else
			{
				c2s.uc[0] = TIMEOUT;
			}
		}
		else
		{
			c2s.uc[0] = TIMEOUT;
		}

		/* Run User App on Timeout */
		if ( c2s.uc[0] == TIMEOUT )
		{
			SendLFCR();
			address = (read_datum *)BLK_UPDATE_ADD;
			nddd = *(__IO uint8_t*) address;
			if ( nddd == 2 )
			{
				p = (read_datum*)CHECK_ADD_SECOND_BLK;
			}
			else
			{
				p = (read_datum*)CHECK_ADD_FIRST_BLK;
			}

			if ( *p != 0xffffffff )
			{
				/* ReSet Process Word - Clear all Status Flags before running User Application*/
					//set_psw(0);

				SendLFCR();
				SendString((uint8_t*)"Running user program...", 23);
				SendLFCR();

				/* Call user program and never return */
				if ( nddd == 2 )
				{
					RunUserApp(SECOND_USER_FLASH_ADDR_START);
				}
				else
				{
					RunUserApp(FIRST_USER_FLASH_ADDR_START);
				}
			}
			else
			{
				/* System Reset */
				NVIC_SystemReset();
			}
		}
		else
		{
			/* Display menu on UART at which Password Bytes are received */
			ShowMenu();

			#if (FLASHCODE == 1)

			while (1)
			{
				c2s.us = GetByte (10);
				if ( c2s.uc[0] == OK )
					{
						switch ( c2s.uc[1] )
							{
								case '1':
									Command_1_2(1);	              //Blank checking First Block user area
									break;

								case '2':
									Command_1_2(2);	                 //Blank checking First Block user area
									break;

								case '3':
									Command_9();	              // Update Firmware
									break;

								case '4':
									Command_5();	              // Run updated program
									break;

								default:
									ShowMenu();                   //Show Menu on Display
							}
					}
					else
					{
						  runcode++;
						  if(10 < runcode)
							{
								runcode = 0;
								/* System Reset */
								NVIC_SystemReset();
							}
					}
			}
			#endif
		}
}

/**************************************************************************************************/
/*   RunUserApp function For running user Application Block  */
/**************************************************************************************************/
void RunUserApp(uint32_t address)
{
	/* Test if user code is programmed starting from address "APPLICATION_ADDRESS" */
	if (((*(__IO uint32_t*)address) & 0x2FFE0000 ) == 0x20000000)
	{
	  /* Jump to user application */
		JumpAddress = 0;
	  JumpAddress = *(__IO uint32_t*) (address + 4);


	  Jump_To_Application = (pFunction) JumpAddress;


	  /* Initialize user application's Stack Pointer */
	  __set_MSP(*(__IO uint32_t*) address);

	  /* Jump to application */
	  Jump_To_Application();
	}
	return;
}



/**************************************************************************************************/
/*    ShowMenu function                                                                           */
/**************************************************************************************************/
void ShowMenu (void)
{
//	union union_c2s c2s;
	SendLFCR();
	SendString( (uint8_t*)"RX220 Bootloader Main Menu ver.->3.4.02",38);
	SendLFCR();
	SendString((uint8_t*)"---------------------------------------",39);
	SendLFCR();
	SendString( (uint8_t*)"1...Blank Check User Area FIRST",31 );
	SendLFCR();
	SendString( (uint8_t*)"2...Blank Check User Area SECOND",32 );
	SendLFCR();
	SendString( (uint8_t*)"3...Firmware Updating", 21);
	SendLFCR();
	SendString( (uint8_t*)"4...RUN Updated Firmware",24 );
	SendLFCR();
	SendByte( '>' );
}

/**************************************************************************************************/
/*    Command_1_2 function - Check if "User Area 1" OR "User Area 2" is blank                                                                           */
/**************************************************************************************************/
void Command_1_2 (uint8_t block)
{
	read_datum *startAddress = (void*)0, *endAddress = (void*)0;
	unsigned char blank;

	SendLFCR();

	if(block == 1)
	{
		SendString((uint8_t*)"Blank checking First Block user area...",38 );
	}
	else
	{
		SendString((uint8_t*)"Blank checking Second Block user area...",40);
	}
	SendLFCR();

	if(block == 1)
	{
		startAddress = (read_datum *)FIRST_USER_FLASH_ADDR_START ;
		endAddress = (read_datum *) FIRST_USER_FLASH_ADDR_END ;
	}
	else
	{
		startAddress = (read_datum *)SECOND_USER_FLASH_ADDR_START;
		endAddress = (read_datum *)SECOND_USER_FLASH_ADDR_END;
	}


	blank = 0;
	while( startAddress < endAddress)
		{
			if ( *startAddress != BLANK_VALUE )
				{
					blank = 1; //NOT blank
					break;
				}
			startAddress++;
		}

	SendLFCR();

	if(block == 1)
	{
		SendString( (uint8_t*)"FIRST User area is",18);
	}
	else
	{
		SendString((uint8_t*) "SECOND User area is ",20 );
	}

	if ( blank == 0 )
	{
		SendString((uint8_t*)"BLANK!",6 );
		SendLFCR();
		ShowMenu();
	}
	else
	{
		SendString((uint8_t*)"NOT blank!",10);
		SendLFCR();
		ShowMenu();
	}
}


/**************************************************************************************************/
/*    Command_9 function For Updated Firmware not Write in current running user Block - MANI      */
/**************************************************************************************************/
void Command_9 (void)
{
	SendLFCR();

	read_datum *address;
	char nddd;
	address = (read_datum *) BLK_UPDATE_ADD;
	nddd = *(__IO uint8_t*)address;
	if ( nddd == 2 )
	{
		//Command_3();
	}

	else
	{
		Command_3();
		//Command_4 ();
	}
//	PurgeComms(2);
	ShowMenu();

}



/**************************************************************************************************/
/*    Command_3 function                                                                          */
/**************************************************************************************************/
void Command_3 (void)
{
	// download data using xmodem and program into flash First Block
	unsigned char Status , updateStatus, RxByteBuffer[8] = {0}; //, Shift;
	read_datum  *address1;
	read_datum  *address2;
	//volatile unsigned long Address, ul;
	union union_c2s c2s;
	char l_Check_First1,l_Check_First2;//,l_Check_First,RxByteBuffer[4];
	//unsigned int i;
//	uint32_t updateData = 0x00000002;
	uint32_t page = 0;


	// suggest download address as the first user flash address as usually this will be the case
	SendLFCR();
	SendString( (uint8_t*)"Erase FIRST User Block",22);

	Address = 0;
//	Shift = 28;

	SendLFCR();
	SendString((uint8_t*)FIRST_USER_FL_ADDR_TXT,12);

	SendString( (uint8_t*)"     (Y/N)?",11 );

	/* wait for 10 seconds to receive bytes */
	c2s.us = GetByte(10);
	SendByte( c2s.uc[1] );
	SendLFCR();
	if ( c2s.uc[0] == TIMEOUT )
	{
		SendLFCR();
		SendString( (uint8_t*)"Timed out waiting for confirmation...",37 );
		return ;
	}
	else if (  ( c2s.uc[1] == 'y' ) || ( c2s.uc[1] == 'Y' ) )
	{
		Command_6();                                     // Erase first user Block
		Address = FIRST_USER_FLASH_ADDR_START;
		EndAddress = FIRST_USER_FLASH_ADDR_END;
	}
	else
	{
		//Command_5 ();                                     // Run updated program		//To be chk NDY
	}
	SendLFCR();
	SendString( (uint8_t*)"Firmware downloading (Y/N)?",28 );
	c2s.us = GetByte( 10 );
	SendByte( c2s.uc[1] );
	SendLFCR();
	if ( c2s.uc[0] == TIMEOUT )
	{
		SendLFCR();
		SendString((uint8_t*)"Timed out waiting for response!",31 );
		return ;
	}
	else if ( c2s.uc[0] == ERROR )
	{
		SendLFCR();
		SendString( (uint8_t*)"Comms Error!",12 );
		return ;
	}
	else if ( !( ( c2s.uc[1] == 'y' ) || ( c2s.uc[1] == 'Y' ) ) )
	{
		SendLFCR();
		SendString( (uint8_t*)"Firmware downloading cancelled!",31 );
		return ;
	}

		SendLFCR();
		SendString( (uint8_t*)"Start XModem download...",24);
		SendLFCR();




	Flash_Unlock();
	Status = XmodemDownloadAndProgramFlash( Address,EndAddress );
	Flash_Lock();





	Status = XM_OK;





	if ( Status == XM_TIMEOUT )
	{
		SendLFCR();
		SendString( (uint8_t*)"Timeout!",9 );
		return ;
	}
	else if ( Status == XM_OK )
	{
	  //  l_Check_First = CHECK_ADD_FIRST_BLK;
		address1 = (read_datum *)CHECK_ADD_FIRST_BLK11;
		l_Check_First1 = *(__IO uint8_t*)address1;
		address2 = (read_datum *)CHECK_ADD_FIRST_BLK12;
		l_Check_First2 = *(__IO uint8_t*)address2;
		if (1)//(l_Check_First1==0x00 && l_Check_First2==0xFE )
			{
				//Command_8();

			uint64_t data = 0x0000000000000002;




					RxByteBuffer[0] = '0';
					RxByteBuffer[1] = '0';
					RxByteBuffer[2] = '0';

					RxByteBuffer[3] = '0';
					RxByteBuffer[4] = '0';
					RxByteBuffer[5] = '0';

					RxByteBuffer[6] = '0';
					RxByteBuffer[7] = '2';



					     __NOP();
					     __NOP();
					     Flash_Unlock();







				updateStatus = FLASH_Write((unsigned long)BLK_UPDATE_ADD,(unsigned long)BLK_END_ADD,&data,8);
				Flash_Lock();
				if(updateStatus == XM_OK )
				{
					SendLFCR();
					SendString( (uint8_t*)"OK - Firmware downloaded!",25 );
					SendLFCR();
				}
				else
				{
					SendLFCR();
					SendString( (uint8_t*)"Firmware Block Update Failed!",29);
					SendLFCR();
				}

				return ;
			}
		else
		   {
			   SendLFCR();
				SendString( (uint8_t*)"Firmware download FAIL!",23 );
			//	for(i=0; i<650; i++);
			//    SendLFCR();
				return ;
		   }
	}
	else if ( Status == XM_PROG_FAIL )
	{
		SendLFCR();
		SendString( (uint8_t*)"Firmware download FAIL!",23 );
		SendLFCR();
	}
	return ;
}


/**************************************/
/*   Command_5 : Run Program    	*/	  
/*************************************/

void Command_5 (void)
{
	// call the target application
	union union_c2s c2s;
	read_datum *p ,*address;
	char nddd;

	SendLFCR();                                                    // For New line
	SendString((uint8_t*)"Run user program (Y/N)?",23);
	SendLFCR();                                                    // For New line
	c2s.us = GetByte(5);
	SendByte( c2s.uc[1] );
	if ( c2s.uc[0] == TIMEOUT )
	{
		SendLFCR();
		SendString((uint8_t*)"Timed out",9);

		//PurgeComms( 300 );
		ShowMenu();
	}
	else if ( c2s.uc[0] == ERROR )
	{
		SendLFCR();
		SendString((uint8_t*)"ERROR in download",17);
		//PurgeComms( 300 );                                             //For delay
		ShowMenu();
	}
	else if ( !( ( c2s.uc[1] == 'y' ) || ( c2s.uc[1] == 'Y' ) ) )
	{
		SendLFCR();
		SendString((uint8_t*)"request cancelled",17);
		//PurgeComms( 300 );
		ShowMenu();
	}

	SendLFCR();
	address = (read_datum *)BLK_UPDATE_ADD;
	nddd = *(__IO uint8_t*) address;
	if ( nddd == 2 )
	{
		p = (read_datum*)CHECK_ADD_SECOND_BLK;
	}
	else
	{
		p = (read_datum*)CHECK_ADD_FIRST_BLK;
	}

	if ( *p != 0xffffffff )
	{
		/* ReSet Process Word - Clear all Status Flags before running User Application*/
			//set_psw(0);

		SendLFCR();
		SendString((uint8_t*)"Running user program...", 23);
		SendLFCR();

		/* Call user program and never return */
		if ( nddd == 2 )
		{
			RunUserApp(SECOND_USER_FLASH_ADDR_START);
		}
		else
		{
			RunUserApp(FIRST_USER_FLASH_ADDR_START);
		}
	}
	else
	{
		/* System Reset */
		NVIC_SystemReset();
	}
}

/**************************************/
/*    Command_6 function              */
/**************************************/
void Command_6 (void)
{
//	unsigned char uc;
//	unsigned char Status;
	union union_c2s c2s;
//	unsigned char count1;
	 uint32_t index=0;

	SendLFCR();

	SendString( (uint8_t*)"Really erase FIRST user blocks (Y/N)?",37 );
	c2s.us = GetByte( 10 );
	SendByte( c2s.uc[1] );
	SendLFCR();
//	c2s.uc[1] = 'y';
//	PurgeComms( 300 );
	if ( c2s.uc[0] == TIMEOUT )
	{
		SendLFCR();
		SendString( (uint8_t*)"Timed out waiting for response",25 );
		return;
	}
	else if ( c2s.uc[0] == ERROR )
	{
		SendLFCR();
		SendString( (uint8_t*)"Comms error",11 );
		return;
	}
	else if ( !( ( c2s.uc[1] == 'y' ) || ( c2s.uc[1] == 'Y' ) ) )
	{
		SendLFCR();
		SendString( (uint8_t*)"FIRST blocks erase cancelled",28 );
		return;
	}

/****************** FLASH CODE EXAMPLE TO ERASE MEMORY *****************/
	  /* Unlock the Flash to enable the flash control register access *************/
		Flash_Unlock();

	    /* Get the 1st page to erase */
	    FirstPage = GetPage(FIRST_USER_FLASH_ADDR_START);

	    /* Get the number of pages to erase from 1st page */
	    NbOfPages = GetPage(FIRST_USER_FLASH_ADDR_END) - FirstPage + 1;

	    /* Fill EraseInit structure*/
	    EraseInitStruct.TypeErase   = FLASH_TYPEERASE_PAGES;
	    EraseInitStruct.Page        = FirstPage;
	    EraseInitStruct.NbPages     = NbOfPages;

	    /* Note: If an erase operation in Flash memory also concerns data in the data or instruction cache,
	       you have to make sure that these data are rewritten before they are accessed during code
	       execution. If this cannot be done safely, it is recommended to flush the caches by setting the
	       DCRST and ICRST bits in the FLASH_CR register. */

	    /* Wait for last operation to be completed */
	    while(READ_BIT(FLASH->SR,FLASH_SR_BSY1) == FLASH_SR_BSY1);

	    /*Initialization of PageError variable*/

	    for (index = FirstPage; index < (FirstPage + NbOfPages); index++)
	    {
	      /* Start erase page */
	    	  uint32_t tmp;
	    	  /* Get configuration register, then clear page number */
	    	  tmp = (FLASH->CR & ~FLASH_CR_PNB);
	    	  /* Set page number, Page Erase bit & Start bit */
	    	  FLASH->CR = (tmp | (FLASH_CR_STRT | (index <<  FLASH_CR_PNB_Pos) | FLASH_CR_PER));


	      /* Wait for last operation to be completed */
	       while(READ_BIT(FLASH->SR,FLASH_SR_BSY1) == FLASH_SR_BSY1);
	    }

	     /* If operation is completed or interrupted, disable the Page Erase Bit */
	     CLEAR_BIT(FLASH->CR, FLASH_CR_PER);

	    /* Lock the Flash to disable the flash control register access (recommended
	       to protect the FLASH memory against possible unwanted operation) *********/
	     Flash_Lock();


	    /*******************************************************************************/

	SendLFCR();
	SendString( (uint8_t*)"All user blocks erased", 21);
	SendLFCR();
}




/**************************************/
/*    Command_8 function              */
/**************************************/
void Command_8 (void)
{
	// erase the specified flash block
//	union union_c2s c2s;
//	uint8_t Status;
//	char str[5];

	SendLFCR();

//	c2s.uc[1] = 'y';
//	if (  ( c2s.uc[1] == 'y' ) || ( c2s.uc[1] == 'Y' ) )
//		{
//			// call the erase function with the block to be erased and a dummy value (0)
//		//	Status = R_FlashErase( USER_FLASH_BLK_UPDATE);
//		Status = 0;
//		/****************** FLASH CODE EXAMPLE TO ERASE MEMORY *****************/
//			  /* Unlock the Flash to enable the flash control register access *************/
//			//	Flash_Unlock();
//
//			    /* Get the 1st page to erase */
//			    FirstPage = GetPage(FIRST_USER_FLASH_ADDR_START);
//
//			    /* Get the number of pages to erase from 1st page */
//			    NbOfPages = GetPage(FIRST_USER_FLASH_ADDR_END) - FirstPage + 1;
//
//			    /* Fill EraseInit structure*/
//			    EraseInitStruct.TypeErase   = FLASH_TYPEERASE_PAGES;
//			    EraseInitStruct.Page        = FirstPage;
//			    EraseInitStruct.NbPages     = NbOfPages;
//
//			    /* Note: If an erase operation in Flash memory also concerns data in the data or instruction cache,
//			       you have to make sure that these data are rewritten before they are accessed during code
//			       execution. If this cannot be done safely, it is recommended to flush the caches by setting the
//			       DCRST and ICRST bits in the FLASH_CR register. */
//
//			    /* Wait for last operation to be completed */
//			    while(READ_BIT(FLASH->SR,FLASH_SR_BSY1) == FLASH_SR_BSY1);
//
//			    /*Initialization of PageError variable*/
//
//			    for (index = FirstPage; index < (FirstPage + NbOfPages); index++)
//			    {
//			      /* Start erase page */
//			    	  uint32_t tmp;
//			    	  /* Get configuration register, then clear page number */
//			    	  tmp = (FLASH->CR & ~FLASH_CR_PNB);
//			    	  /* Set page number, Page Erase bit & Start bit */
//			    	  FLASH->CR = (tmp | (FLASH_CR_STRT | (index <<  FLASH_CR_PNB_Pos) | FLASH_CR_PER));
//
//
//			      /* Wait for last operation to be completed */
//			       while(READ_BIT(FLASH->SR,FLASH_SR_BSY1) == FLASH_SR_BSY1);
//			    }
//
//			     /* If operation is completed or interrupted, disable the Page Erase Bit */
//			     CLEAR_BIT(FLASH->CR, FLASH_CR_PER);
//
//			    /* Lock the Flash to disable the flash control register access (recommended
//			       to protect the FLASH memory against possible unwanted operation) *********/
//			 //   HAL_FLASH_Lock();
//
//
//
//			    /*******************************************************************************/
//
//
//
//			SendLFCR();
//		//	itoa( USER_FLASH_BLK_UPDATE, str, 2 );
//			SendString( (uint8_t *)"Erasing of block ",17 );
//			SendByte(USER_FLASH_BLK_UPDATE + 48 );
//			if ( Status == 1u )
//				{
//					SendString( " FAIL" );SendLFCR();
//				}
//			else
//				{
//					SendString( " PASS" );SendLFCR();
//				}
//			return;
//		}
//	else
//		{
//			SendLFCR();
//			SendString( "Block erase cancelled" );
//			return;
//		}
}


void Testing_flash_clear(void)
{
	uint32_t index=0;

	  /* Unlock the Flash to enable the flash control register access *************/
			Flash_Unlock();

		    /* Get the 1st page to erase */
		    FirstPage = GetPage(0x8003ffd);

		    /* Get the number of pages to erase from 1st page */
		    NbOfPages = GetPage(0x8003fff) - FirstPage + 1;

		    /* Fill EraseInit structure*/
		    EraseInitStruct.TypeErase   = FLASH_TYPEERASE_PAGES;
		    EraseInitStruct.Page        = FirstPage;
		    EraseInitStruct.NbPages     = NbOfPages;

		    /* Note: If an erase operation in Flash memory also concerns data in the data or instruction cache,
		       you have to make sure that these data are rewritten before they are accessed during code
		       execution. If this cannot be done safely, it is recommended to flush the caches by setting the
		       DCRST and ICRST bits in the FLASH_CR register. */

		    /* Wait for last operation to be completed */
		    while(READ_BIT(FLASH->SR,FLASH_SR_BSY1) == FLASH_SR_BSY1);

		    /*Initialization of PageError variable*/

		    for (index = FirstPage; index < (FirstPage + NbOfPages); index++)
		    {
		      /* Start erase page */
		    	  uint32_t tmp;
		    	  /* Get configuration register, then clear page number */
		    	  tmp = (FLASH->CR & ~FLASH_CR_PNB);
		    	  /* Set page number, Page Erase bit & Start bit */
		    	  FLASH->CR = (tmp | (FLASH_CR_STRT | (index <<  FLASH_CR_PNB_Pos) | FLASH_CR_PER));


		      /* Wait for last operation to be completed */
		       while(READ_BIT(FLASH->SR,FLASH_SR_BSY1) == FLASH_SR_BSY1);
		    }

		     /* If operation is completed or interrupted, disable the Page Erase Bit */
		     CLEAR_BIT(FLASH->CR, FLASH_CR_PER);

		    /* Lock the Flash to disable the flash control register access (recommended
		       to protect the FLASH memory against possible unwanted operation) *********/
		     Flash_Lock();

}


#endif
/* USER CODE END 0 */

/* USER CODE BEGIN 1 */



/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
